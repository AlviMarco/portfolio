package com.hisabpati.app;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

/**
 * MainActivity for Hisab Pati
 * Extends Capacitor's BridgeActivity for seamless React/TypeScript app loading
 */
public class MainActivity extends BridgeActivity {}
