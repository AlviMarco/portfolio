declare module 'react' {
    const React: any;
    export default React;
    export const Component: any;
    export type ReactNode = any;
    export type ErrorInfo = any;
}

declare module 'react-dom/client' {
    const ReactDOM: any;
    export default ReactDOM;
}

declare module 'lucide-react' {
    export const AlertCircle: any;
    export const RefreshCw: any;
    export const Home: any;
    export const TrendingUp: any;
    export const ShoppingCart: any;
    export const ArrowDownLeft: any;
    export const ArrowUpRight: any;
    export const FileText: any;
    export const LayoutDashboard: any;
    export const ClipboardList: any;
    export const ListTree: any;
    export const BarChart3: any;
    export const Settings: any;
    export const Plus: any;
    export const TrendingDown: any;
    export const Wallet: any;
    export const Sparkles: any;
    export const Loader2: any;
    export const CheckCircle2: any;
    export const Search: any;
    export const ChevronRight: any;
    export const ShoppingBag: any;
    export const FileSpreadsheet: any;
    export const FileJson: any;
    export const History: any;
    export const Calendar: any;
    export const Layers: any;
    export const Printer: any;
    export const Library: any;
    export const Eye: any;
    export const EyeOff: any;
    export const Upload: any;
    export const Filter: any;
    export const Coins: any;
    export const ArrowRight: any;
    export const Lock: any;
}
